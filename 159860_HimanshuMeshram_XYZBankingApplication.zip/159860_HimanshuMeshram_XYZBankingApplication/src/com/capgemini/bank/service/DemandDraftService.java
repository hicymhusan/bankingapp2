package com.capgemini.bank.service;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.util.ConnectionProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;	
public class DemandDraftService implements IDemandDraftService{
	static IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException{
		try{
		int transactionId=demandDraftDAO.addDemandDraftDetails(demandDraft);
		demandDraft.setTransactionId(transactionId);
		return transactionId;
		}
		catch(SQLException e){
			throw e;
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
		try{
		DemandDraft demandDraft = demandDraftDAO.getDemandDraftDetails(transactionId);
		return demandDraft;
		}
		catch(SQLException e){
			throw e;
		}
	}
	}


