package com.capgemini.bank.bean;

import java.sql.Date;

public class DemandDraft {
	private  int transactionId,amount,commission;
	private String customerName,inFavorOf,contactDetails;
	private String description;
	private Date transactionDate;
	public DemandDraft() {
		super();
	}
	public DemandDraft( int amount,
			String customerName, String inFavorOf, String contactDetails,
			String description) {
		super();
		this.amount = amount;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.contactDetails = contactDetails;
		this.description = description;
	
	}
	public DemandDraft(int transaction, int amount2, int commission2,
			String name, String in_favor_of, String phoneNo,
			String description2, Date transactionDate2) {
		// TODO Auto-generated constructor stub
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getCommission() {
		
		return commission;
	}
	public void setCommission(int amount) {
		if(amount<=5000)
			this.commission=10;
		else if(amount>=5001 && amount<10000)
			this.commission=41;
		else if(amount>=10001 && amount<100000)
			this.commission=51;
		else if(amount>=100001 && amount<500000)
			this.commission=306;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public String getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
}
