package com.capgemini.bank.exceptions;

public class BankServicesDownException {

}
