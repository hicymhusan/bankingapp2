package com.capgemini.bank.ui;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;
public class Client {
	private static Scanner in;
	public static void main(String[] args) throws SQLException{
		if (ConnectionProvider.getDBConnectionProvider() != null)
			System.out.println("Successfully Connected");
		else
			System.out.println("Not Connected");
		int num;
		char c='Y';
		DemandDraft demandDraft=new DemandDraft();
		while(c=='Y'){
			System.out.println("Enter the number to proceed");
			System.out.println("1.Enter Demand Draft Details");
			System.out.println("2.Exit");
			in = new Scanner(System.in);
			num=in.nextInt();
			switch(num){
			case 1:
			{
				IDemandDraftService demandDraftService=new DemandDraftService();
				System.out.println("Enter the name of the customer");
				demandDraft.setCustomerName(in.next());
				System.out.println("Enter Customer phone number");
				demandDraft.setContactDetails(in.next());
				System.out.println("In favor of");
				demandDraft.setInFavorOf(in.next());
				System.out.println("Enter Demand Draft amount (in Rs)");
				demandDraft.setAmount(in.nextInt());
				System.out.println("Enter Remarks");
				demandDraft.setDescription(in.next());
				demandDraft.setCommission(demandDraft.getAmount());
				int transactionId=demandDraftService.addDemandDraftDetails(demandDraft);
				System.out.println("The demand draft details are updated with transaction ID:"+transactionId);
				break;
			}
			case 2:{
				break;
			}
			}
		}
	}
}

