package com.capgemini.bank.dao;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;	
public class DemandDraftDAO implements IDemandDraftDAO {
	private Connection conn = ConnectionProvider.getDBConnectionProvider();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("INSERT INTO demand_draft values(Transaction_Id_Seq.nextval,?,?,?,sysdate,?,?,?)");
			pstmt1.setString(1, demandDraft.getCustomerName());
			pstmt1.setString(2, demandDraft.getInFavorOf());
			pstmt1.setString(3, demandDraft.getContactDetails());
			pstmt1.setInt(4, demandDraft.getAmount());
			pstmt1.setInt(5, demandDraft.getCommission());
			pstmt1.setString(6, demandDraft.getDescription());
			pstmt1.executeUpdate();
			conn.commit();
			PreparedStatement pstmt2 = conn.prepareStatement("select max(transaction_id) from demand_draft");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int transactionId = rs.getInt(1);
			demandDraft.setTransactionId(transactionId);
			return transactionId;
		}catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		} finally {
			conn.setAutoCommit(true);
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails (int transactionId){
		try {
			PreparedStatement pstmt1;
			pstmt1 = conn.prepareStatement("SELECT * FROM demand_draft WHERE transaction_id =" + transactionId);
			ResultSet demandDraftRS = pstmt1.executeQuery();
			DemandDraft demandDraft = null;
			if (demandDraftRS.next()) {
				int transaction=demandDraftRS.getInt("transaction_id");
				String Name = demandDraftRS.getString("customer_name");
				String in_favor_of = demandDraftRS.getString("in_favor_of");
				String phoneNo = demandDraftRS.getString("phoneno");
				demandDraft.setTransactionDate(demandDraftRS.getDate("date_of_transaction"));
				int amount = demandDraftRS.getInt("dd_amount");
				int commission = demandDraftRS.getInt("dd_commission");
				String description = demandDraftRS.getString("dd_description");
				demandDraft = new DemandDraft(transaction,amount, commission,
						Name,in_favor_of, phoneNo,description,demandDraft.getTransactionDate());	
				return demandDraft;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}

