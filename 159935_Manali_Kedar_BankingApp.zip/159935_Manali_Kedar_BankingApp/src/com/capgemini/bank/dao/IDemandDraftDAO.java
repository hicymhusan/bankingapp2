package com.capgemini.bank.dao;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingException;

public interface IDemandDraftDAO {
	int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingException;
	DemandDraft getDemandDraftDetails(int transactionId) throws BankingException, SQLException;
}
