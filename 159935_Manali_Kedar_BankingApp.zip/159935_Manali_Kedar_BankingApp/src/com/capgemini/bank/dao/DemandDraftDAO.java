package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;





import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingException;
import com.cg.bank.util.ConnectionProvider;



public class DemandDraftDAO implements IDemandDraftDAO {
	Logger logger = Logger.getLogger(DemandDraftDAO.class);
	private static Connection conn = ConnectionProvider.getDbConnection();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingException{
		try{
			Date date=Date.valueOf(LocalDate.now());
			if(demandDraft.getAmount()<5000)
				demandDraft.setCommision(10);
			else if(demandDraft.getAmount()>5000||demandDraft.getAmount()<10000)
				demandDraft.setCommision(41);
			else if(demandDraft.getAmount()>10001||demandDraft.getAmount()<100000)
				demandDraft.setCommision(51);
			else if(demandDraft.getAmount()>100001 || demandDraft.getAmount()<500000)
				demandDraft.setCommision(306);
			else
				throw new BankingException("Amount Invalid");
			conn.setAutoCommit(false);
			PreparedStatement ps1=conn.prepareStatement("INSERT INTO demand_draft values(Transaction_Id_Seq.nextval,?,?,?,sysdate,?,?,?)");
			ps1.setString(1, demandDraft.getCustomerName());
			ps1.setString(2, demandDraft.getInFavorOf());
			ps1.setString(3, demandDraft.getPhoneNo());
		//	ps1.setDate(4, date);
			ps1.setInt(4, demandDraft.getAmount());
			ps1.setInt(5,demandDraft.getCommision());
			ps1.setString(6, demandDraft.getRemarks());

			ps1.executeUpdate();
			conn.commit();
			PreparedStatement ps2 = conn.prepareStatement("select max(transaction_id) from demand_draft");
			ResultSet rs=ps2.executeQuery();
			rs.next();
			int transactionId=rs.getInt(1);
			logger.info("DD added with id "+transactionId);
			return transactionId;
		}
		catch(SQLException e){
			logger.error(e.getMessage()+" "+e.getErrorCode());
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankingException, SQLException {
		try {
			PreparedStatement pstmt1 = conn.prepareStatement("Select * from demand_draft where transaction_id="+transactionId);

			ResultSet RS=pstmt1.executeQuery();
			if(RS.next()){
				DemandDraft demandDraft= new DemandDraft(RS.getString(2), RS.getString(4), RS.getString(3), RS.getString(8), RS.getInt(6), RS.getInt(1), RS.getInt(7),RS.getDate(5));
				//System.out.println(RS.getDate(5));
				return demandDraft;
			}
			else
				throw new SQLException();
			} catch (SQLException e) {
				logger.error(e.getMessage()+" "+e.getErrorCode());
				throw e;
			}
		}

	}
