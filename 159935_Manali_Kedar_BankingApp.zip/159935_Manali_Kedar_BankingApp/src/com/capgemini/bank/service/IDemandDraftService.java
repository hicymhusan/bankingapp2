package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingException;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingException;
	DemandDraft getDemandDraftDetails(int transactionId) throws BankingException, SQLException;
	public boolean isValidDetails(DemandDraft demandDraft) throws BankingException;
}
