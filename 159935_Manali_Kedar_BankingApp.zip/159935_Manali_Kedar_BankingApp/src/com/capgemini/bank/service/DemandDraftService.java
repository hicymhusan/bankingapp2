package com.capgemini.bank.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.BankingException;

public class DemandDraftService implements IDemandDraftService{
	static IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingException {
		try{
		int transactionId=demandDraftDAO.addDemandDraftDetails(demandDraft);
		demandDraft.setTransactionId(transactionId);
		return transactionId;
		}
		catch(BankingException e){
			throw e;
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankingException, SQLException {
		try{
		DemandDraft demandDraft = demandDraftDAO.getDemandDraftDetails(transactionId);
		return demandDraft;
		}
		catch(BankingException e){
			throw e;
		}
	}
	
	@Override
	public boolean isValidDetails(DemandDraft demandDraft) throws BankingException {
		List<String> validationErrors = new ArrayList<String>();
		if (!(isValidName(demandDraft.getCustomerName()))) {
			validationErrors
					.add("\n Name Should Be In Alphabets and minimum 3 characters long ! ");
		}

		// Validating Phone Number
		if (!(isValidPhoneNumber(demandDraft.getPhoneNo()))) {
			validationErrors.add("\n Phone Number Should be of 10 digit ");
		}
		// Validating inFavorOf
		if (demandDraft.getInFavorOf().isEmpty()) {
			validationErrors
					.add("\n Empty field ");
		}

		// Validating Amount
		if (demandDraft.getAmount()==0) {
			validationErrors.add("\n Please enter amount\n");
		}
		if (demandDraft.getRemarks().isEmpty()) {
			validationErrors
					.add("\n Empty field ");
		}

		if (!validationErrors.isEmpty()) {
			throw new BankingException(validationErrors + "");
		} else
			return true;
	}

	private boolean isValidPhoneNumber(CharSequence c) {
		Pattern phonePattern = Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher = phonePattern.matcher(c);
		return phoneMatcher.matches();
	}

	private boolean isValidName(String customerName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(customerName);
		return nameMatcher.matches();
	}

}
