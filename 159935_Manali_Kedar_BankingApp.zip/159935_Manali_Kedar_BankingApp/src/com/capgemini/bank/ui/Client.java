package com.capgemini.bank.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log.properties");
		IDemandDraftService demandDraftService= new DemandDraftService();
		System.out.println("Choose one option from menu\n1) Enter Demand Draft Details");
		System.out.println("2) Exit ");
		int choice = s.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter the name of customer: ");
			String customerName = s.next();
			System.out.println("Enter customer phone number: ");
			String phoneNo=s.next();
			System.out.println("In favor of: ");
			String inFavorOf = s.next();
			System.out.println("Enter Demand Draft amount (in Rs): ");
			int amount= s.nextInt();
			System.out.println("Enter Remarks");
			String remarks = s.next();
			try{
				DemandDraft demandDraft = new DemandDraft(customerName, inFavorOf, remarks, phoneNo, amount);
				//Check if details are valid
				demandDraftService.isValidDetails(demandDraft);
				//Adding details to demand_drft table
				int transactionId=demandDraftService.addDemandDraftDetails(demandDraft);
				System.out.println("Your demand draft request has been successfully registered along with transaction id: "+transactionId);
				//Getting details of record added currently in demand_draft table
				DemandDraft demandDraft2 = demandDraftService.getDemandDraftDetails(transactionId);
				System.out.println("DD details are: ");
				System.out.println(demandDraft.toString());
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Thank you on selecting us!!");
			s.close();
			System.exit(0);
		default:
			System.out.println("Enter a valid option");
		}
	}
}
