package com.capgemini.bank.bean;

import java.sql.Date;



public class DemandDraft {
	private  String customerName, phoneNo,inFavorOf,remarks;
	private  int amount;
	private int transactionId,commision;
	private Date dateOfTransaction;
	
	public DemandDraft(String customerName, String phoneNo, String inFavorOf,
			String remarks, int amount, int transactionId, int commision,
			Date dateOfTransaction) {
		super();
		this.customerName = customerName;
		this.phoneNo = phoneNo;
		this.inFavorOf = inFavorOf;
		this.remarks = remarks;
		this.amount = amount;
		this.transactionId = transactionId;
		this.commision = commision;
		this.dateOfTransaction = dateOfTransaction;
	}
	//constructor
	public DemandDraft(String customerName, String inFavorOf, String remarks,
			String phoneNo, int amount) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.remarks = remarks;
		this.phoneNo = phoneNo;
		this.amount = amount;
	}
	//getters and setters
	public DemandDraft() {
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public int getCommision() {
		return commision;
	}
	public void setCommision(int commision) {
		this.commision = commision;
	}
	@Override
	public String toString() {
		return "DemandDraft [customerName=" + customerName + ", phoneNo="
				+ phoneNo + ", inFavorOf=" + inFavorOf + ", remarks=" + remarks
				+ ", amount=" + amount + ", transactionId=" + transactionId
				+ ", commision=" + commision + ", dateOfTransaction="
				+ dateOfTransaction + "]";
	}

	

	
	
	
	
}
